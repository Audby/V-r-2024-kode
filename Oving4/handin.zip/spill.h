#include "std_lib_facilities.h"

int checkCharactersAndPosition(string code, string guess);

void playMastermind();

int checkCharacters(string code, string guess);
