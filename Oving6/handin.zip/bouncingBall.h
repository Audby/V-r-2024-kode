#pragma once

void bouncingBall();

string getColor(int colorCode);