#include <vector>
#include "std_lib_facilities.h"

int randomWithLimits(int nedre, int ovre);

double getUserInputInitVelocity();

double degToRad();

void playTargetPractice();